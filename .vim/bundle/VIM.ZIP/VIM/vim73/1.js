if (condition) {
    //code
}
function function_name (argument) {
    // body...
}
function function_name (argument) {
    // body...
}
