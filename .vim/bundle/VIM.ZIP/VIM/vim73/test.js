var foo = 1;
var bar = 'a';
var foobar = foo + bar;
